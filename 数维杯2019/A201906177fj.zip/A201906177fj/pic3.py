from example.commons import Faker
from pyecharts import options as opts
from pyecharts.charts import Bar,Funnel
from pyecharts.globals import ThemeType
# 新疆：0.8096，西藏：0.4148，青海：0.4021，广东：0.3517，四川：0.3420，贵州：0.3305.。。。。。。。。。陕西：0.2194
# 农民：0.6886，家政家务，0.4613，退休人员0.3995，公共人员：0.3869，商务人员0.2896，散居儿童：0.2840，工人：0.2661
import pandas as pd
import numpy as np
import random
import matplotlib
from matplotlib import pyplot as plt
from matplotlib import font_manager
my_font = font_manager.FontProperties(fname="C:\Windows\Fonts\msyh.ttc")#微软雅黑字体位置
from sklearn.metrics import explained_variance_score,mean_squared_error
def bar_xyaxis_name() -> Bar:
    c = (
        Bar()
        .add_xaxis(["新疆","西藏","青海","广东","四川","贵州","天津"])
        .add_yaxis("", [0.6096,0.4148,0.4021,0.3517,0.3420,0.3305,0.3241])
        # .add_yaxis("商家B", Faker.values())
        .set_global_opts(
            title_opts=opts.TitleOpts(title="不同区域TOPSIS打分情况"),
            yaxis_opts=opts.AxisOpts(name="监测程度"),
            toolbox_opts=opts.ToolboxOpts(),
            xaxis_opts=opts.AxisOpts(name="重点监测区域"),
            legend_opts=opts.LegendOpts(is_show=False)
        )
    )
    return c

def bar_xyzaxis_name() -> Bar:
    c = (
        Bar()
        .add_xaxis(["heart","Respiratory","Cerebrovascular","Cancer","Immunodeficiency","......","Parasite"])
        .add_yaxis("", [0.6886,0.4613,0.3995,0.3869,0.2896,0.2840,0.2661])
        # .add_yaxis("商家B", Faker.values())
        .set_global_opts(
            title_opts=opts.TitleOpts(title="TOPSIS scores for different diseases"),
            # yaxis_opts=opts.AxisOpts(name="监测程度"),
            toolbox_opts=opts.ToolboxOpts(),
            # xaxis_opts=opts.AxisOpts(name="重点监测人权"),
            legend_opts=opts.LegendOpts(is_show=False)
        )
    )
    return c

def funnel_label_inside() -> Funnel:
    c = (
        Funnel()
        .add(
            "",
            [list(z) for z in zip(["heart disease","Respiratory disease","Cerebrovascular disease","Cancer","Immunodeficiency","......","Parasite"], [0.6886,0.4613,0.3995,0.3869,0.2896,0.2840,0.2661])],
            label_opts=opts.LabelOpts(position="inside"),
        )
        .set_global_opts(title_opts=opts.TitleOpts(title=""))
    )
    return c

# funnel_label_inside().render()
# plt.figure(figsize=(15, 8), dpi=80)
x = [2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021]
# 两条曲线标注说明,
plt.plot(x,[128.8231	,129.1872	,132.0385	,131.6355	,133.8391	,136.2059,	136.6068	,138.6991	,141.613	,146.34	,
            149.45	,153.454	,155.6778
], label='heart disease')  # 虚线
# plt.plot(x, [54916,	67490.08141	,78063.99174	,81181.69584,	106503.6705,	110400.3167
# ], label='家政家务/人')  # 点划线
# plt.plot(x, [47991	,48952.06066	,43076.23039	,40811.81632	,34969.5661,	33507.68682
# ], label='退休人员/人',color="red")  # 点划线


# 设置刻度
_xtick_labels = ["{}".format(int(i)) for i in x]
plt.xticks(x, _xtick_labels, fontproperties=my_font)
# plt.yticks(range(0, 9))

# 绘制网格
plt.grid(alpha=0.3, linestyle="--")  # alpha为透明度 0-1
plt.title("Focus on diseases", fontproperties=my_font)
plt.xlabel("year", fontproperties=my_font)
plt.ylabel("sick/thousand", fontproperties=my_font)
# 标注图例
plt.legend(prop=my_font, loc=0)
plt.show()
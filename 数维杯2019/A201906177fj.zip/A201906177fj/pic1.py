import pandas as pd
import numpy as np
import random
import matplotlib
from matplotlib import pyplot as plt
from matplotlib import font_manager
my_font = font_manager.FontProperties(fname="C:\Windows\Fonts\msyh.ttc")#微软雅黑字体位置
from sklearn.metrics import explained_variance_score,mean_squared_error
def evalmape(y_true, y_pred):
    n = len(y_true)
    mape = sum(np.abs((y_true - y_pred)/y_true))/n
    return mape

def nse(y_true, y_pred):
    return 1 - (sum((y_true-y_pred)**2)/sum((y_true-np.mean(y_true))**2))

if __name__ == "__main__":
    filename = r'data.xlsx'
    data = pd.read_excel(filename)
    x = [2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021]
    y1 = [11307,11894,12288	,12714	,13161,	13755	,14386	,15203,	15831	,16658]
    y2 = [11307,11964,12588	,12311	,13645,	13199	,14766	,15320,	16301	,17058,17234,17541,17574]
    y3 =[11307,11794,12388	,12611	,13245,	13599	,14476	,15340,	16101	,16958,16934,17441,17511]
    # 设置图形大小
    plt.figure(figsize=(15, 8), dpi=80)

    # 两条曲线标注说明
    plt.plot(x[0:10],y1 , label='True',linestyle="-.")  # 虚线
    plt.plot(x, y2, label='GM(1,1)', linestyle=":")  # 点划线
    plt.plot(x, y3, label='Markov-GM(1,1)',color="red")  # 点划线

    # 设置刻度
    _xtick_labels = ["{}".format(int(i)) for i in x]
    plt.xticks(x, _xtick_labels, fontproperties=my_font)
    # plt.yticks(range(0, 9))

    # 绘制网格
    plt.grid(alpha=0.3, linestyle="--")  # alpha为透明度 0-1
    plt.title("Comparison curve of prediction value of the number of the elderly", fontproperties=my_font)
    plt.xlabel("T / year", fontproperties=my_font)
    plt.ylabel("Number / million", fontproperties=my_font)
    # 标注图例
    plt.legend(prop=my_font, loc=0)

    # 展示
    plt.show()

    mse_predict = mean_squared_error(y1, y2[0:10])
    print(np.sqrt(mse_predict))
    MAPE = evalmape(pd.DataFrame(y1), pd.DataFrame(y2)[0:10])
    print(MAPE)
    # NSE = nse(pd.DataFrame(y1), pd.DataFrame(y2)[0:10])
    # print(NSE)
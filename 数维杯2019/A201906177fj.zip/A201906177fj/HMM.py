# import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

if __name__ == "__main__":
    filename = r'data.xlsx'
    data = pd.read_excel(filename)
    y = data['发病数'].values[0:13]
    predict = data["发病数预测"].values[0:13]

    exc  = y-predict
    # print(exc)
    lamada = max(exc)/3
    print(-3*lamada,-lamada,lamada,3*lamada)

    lable = [0]*len(exc)
    for i in range(len(exc)):
        if exc[i]>=-3*lamada and exc[i]<-lamada:
            lable[i]=1
        elif exc[i]<=lamada and exc[i]>=-lamada:
            lable[i]=2
        else:
            lable[i]=3

    print("每年的标签：" + str(lable))
    e1=0
    e2=0
    e3=0
    for i in lable:
        if i==1:
            e1+=1
        elif i==2:
            e2 += 1
        else:
            e3+=1
    P = np.array([e1/len(lable),e2/len(lable),e3/len(lable)])
    print("三个标签的概率P：" + str(P))
    E = np.array([-2*lamada,0,2*lamada])

    print("三个标签的期望E：" + str(E))

    diyihang_fenmu = 0
    diyihang_fenzi = np.array([0]*3)

    dierhang_fenmu = 0
    dierhang_fenzi = np.array([0]*3)

    disanhang_fenmu = 0
    disanhang_fenzi = np.array([0]*3)
    for i in range(len(lable)-1):
        #分母的赋值
        if lable[i] ==1:
            diyihang_fenmu+=1
        elif lable[i] == 2:
            dierhang_fenmu+=1
        else:
            disanhang_fenmu+=1

        #分子的赋值
        if lable[i]==1 and lable[i+1]==1:
            diyihang_fenzi[0] += 1
        if lable[i]==1 and lable[i+1]==2:
            diyihang_fenzi[1] += 1
        if lable[i]==1 and lable[i+1]==3:
            diyihang_fenzi[2] += 1

        if lable[i]==2 and lable[i+1]==1:
            dierhang_fenzi[0] += 1
        if lable[i]==2 and lable[i+1]==2:
            dierhang_fenzi[1] += 1
        if lable[i]==2 and lable[i+1]==3:
            dierhang_fenzi[2] += 1

        if lable[i]==3 and lable[i+1]==1:
            disanhang_fenzi[0] += 1
        if lable[i]==3 and lable[i+1]==2:
            disanhang_fenzi[1] += 1
        if lable[i]==3 and lable[i+1]==3:
            disanhang_fenzi[2] += 1

    P0 = np.array([diyihang_fenzi/diyihang_fenmu,dierhang_fenzi/dierhang_fenmu,disanhang_fenzi/disanhang_fenmu])
    print("概率矩阵P0:"+str(P0))

    pre2017 = np.dot(P,E)
    # print(pre2017)
    print(2239.50918495696-pre2017)
    #
    print(2150.39689699288 - np.dot(np.dot(P, P0),E))

    print(2064.83047520321 - np.dot(np.dot(np.dot(P, P0),P0),E))